// =============================================
// content.js — 타겟 페이지 DOM 제어
// Config와 Actions(message-types)를 참조합니다.
// =============================================

// content_scripts에서는 ES Module 불가 → config.js를 먼저 로드하여 전역 사용
const CFG = (window.DBAuto && window.DBAuto.Config) || {};
const ACT = (window.DBAuto && window.DBAuto.Actions) || {};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    const action = message.action;

    if (action === (ACT.START_AUTO_FILL || 'START_AUTO_FILL')) {
        handleAutoFill(message.data);
        sendResponse({ success: true });

    } else if (action === (ACT.HIGHLIGHT_TAB || 'HIGHLIGHT_TAB')) {
        const overlayId = 'dbauto-highlight-overlay';
        let overlay = document.getElementById(overlayId);

        if (message.active) {
            if (!overlay) {
                overlay = document.createElement('div');
                overlay.id = overlayId;
                overlay.style.cssText = `
                    position: fixed; top: 0; left: 0; width: 100%; height: 100%;
                    border: 8px solid #C2FFA7; box-sizing: border-box;
                    pointer-events: none; z-index: 999999;
                    background: rgba(194, 255, 167, 0.1);
                    box-shadow: inset 0 0 50px rgba(194, 255, 167, 0.3);
                `;
                document.body.appendChild(overlay);
            }
        } else if (overlay) {
            overlay.remove();
        }

    } else if (action === (ACT.GET_FORM_OPTIONS || 'GET_FORM_OPTIONS')) {
        const getOptions = (id) => {
            const select = document.getElementById(id);
            if (!select) return [];
            return Array.from(select.options).map(opt => ({ value: opt.value, text: opt.text }));
        };

        const F = CFG.FIELD_IDS || {};
        const tySelect = document.getElementById(F.RECIPIENT_TYPE || 'svcExecRecipientTyCd');
        const idSelect = document.getElementById(F.RECIPIENT_ID || 'svcExecRecipientId');
        const originalTyVal = tySelect ? tySelect.value : null;
        const originalIdVal = idSelect ? idSelect.value : null;

        const fallbackVictimScan = () => {
            const names = new Set();
            document.querySelectorAll('option').forEach(opt => {
                if (opt.text.includes('피해아동')) names.add(opt.text.trim());
            });
            const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
            let node;
            while ((node = walker.nextNode())) {
                const text = node.nodeValue.trim();
                if (text.includes('피해아동') && text.length > 3 && text.length < 30 && !text.includes('입력')) {
                    names.add(text);
                }
            }
            return Array.from(names);
        };

        const sendFinal = (victimNames) => {
            sendResponse({
                svcClassDetailCd: getOptions(F.SERVICE_DETAIL || 'svcClassDetailCd'),
                svcExecRecipientTyCd: getOptions(F.RECIPIENT_TYPE || 'svcExecRecipientTyCd'),
                svcExecRecipientId: getOptions(F.RECIPIENT_ID || 'svcExecRecipientId'),
                svcProvLocCd: getOptions(F.LOCATION || 'svcProvLocCd'),
                picId: getOptions(F.PIC || 'picId'),
                provMeansCd: getOptions(F.MEANS || 'provMeansCd'),
                provTyCd: getOptions(F.TYPE || 'provTyCd'),
                victimNames: victimNames
            });
        };

        // 대상자 구분이 '피해아동(A)'이 아닌 경우 잠시 'A'로 변경해서 피해아동 데이터를 빼온 뒤 복구
        if (tySelect && originalTyVal !== 'A') {
            tySelect.value = 'A';
            tySelect.dispatchEvent(new Event('change', { bubbles: true }));

            setTimeout(() => {
                const recipientId = F.RECIPIENT_ID || 'svcExecRecipientId';
                const vOptions = getOptions(recipientId);
                const vNames = vOptions.map(o => o.text).filter(t => t.includes('피해아동'));

                // 원래 상태로 완벽 복구
                tySelect.value = originalTyVal;
                tySelect.dispatchEvent(new Event('change', { bubbles: true }));

                setTimeout(() => {
                    if (idSelect && originalIdVal) {
                        idSelect.value = originalIdVal;
                        idSelect.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                    sendFinal(vNames.length > 0 ? vNames : fallbackVictimScan());
                }, 150);
            }, 150);
            return true;
        } else {
            let vNames = [];
            if (originalTyVal === 'A') {
                const recipientId = F.RECIPIENT_ID || 'svcExecRecipientId';
                vNames = getOptions(recipientId).map(o => o.text).filter(t => t.includes('피해아동'));
            }
            sendFinal(vNames.length > 0 ? vNames : fallbackVictimScan());
        }

    } else if (action === (ACT.UPDATE_TY_CD || 'UPDATE_TY_CD_AND_GET_OPTIONS')) {
        const F = CFG.FIELD_IDS || {};
        const tySelect = document.getElementById(F.RECIPIENT_TYPE || 'svcExecRecipientTyCd');
        if (tySelect) {
            tySelect.value = message.value;
            const eventOpts = { bubbles: true, cancelable: true };
            tySelect.dispatchEvent(new Event('change', eventOpts));
            if (!message.silent) {
                tySelect.dispatchEvent(new Event('input', eventOpts));
            }
        }

        setTimeout(() => {
            const recipientId = F.RECIPIENT_ID || 'svcExecRecipientId';
            const selectId = document.getElementById(recipientId);
            const options = selectId ? Array.from(selectId.options).map(opt => ({ value: opt.value, text: opt.text })) : [];
            sendResponse({ svcExecRecipientId: options });
        }, 150);
        return true;
    }
    return true;
});

// 크롬 익스텐션 Isolated World 정책을 우회하여 메인 권한에서 코드를 실행시키는 기법
function executeInMainWorld(element, jsCode = '') {
    const script = document.createElement('script');

    if (jsCode) {
        script.textContent = `(function() { 
            try { 
                ${jsCode} 
            } catch(e) { console.error('[dbauto-main-world] Error executing code:', e); }
        })();`;
    } else if (element) {
        const href = element.getAttribute('href');
        if (href && href.startsWith('javascript:')) {
            const code = href.replace('javascript:', '');
            script.textContent = `(function() { 
                try { ${code} } catch(e) { console.error('[dbauto-main-world]', e); }
            })();`;
        } else {
            const originalId = element.id;
            const tempId = originalId || `dbauto-temp-btn-${Date.now()}`;
            if (!originalId) element.id = tempId;
            script.textContent = `(function() { 
                var btn = document.getElementById('${tempId}'); 
                if (btn) btn.click();
            })();`;
            setTimeout(() => {
                const el = document.getElementById(tempId);
                if (el && !originalId) el.removeAttribute('id');
            }, 300);
        }
    }

    (document.head || document.documentElement).appendChild(script);
    script.remove();
}

async function handleAutoFill(data) {
    try {
        console.log('dbauto data received:', data);
        const F = CFG.FIELD_IDS || {};

        // 스타일 주입
        if (!document.getElementById('dbauto-styles')) {
            const style = document.createElement('style');
            style.id = 'dbauto-styles';
            style.innerHTML = `
                .dbauto-success { border: 2px solid #C2FFA7 !important; transition: all 0.5s; box-shadow: 0 0 10px rgba(194, 255, 167, 0.5); }
                .dbauto-fail { border: 2px dashed #ff5252 !important; background-color: #fff1f1 !important; transition: all 0.3s; }
            `;
            document.head.appendChild(style);
        }

        // 초기화
        document.querySelectorAll('.dbauto-success, .dbauto-fail').forEach(el => {
            el.classList.remove('dbauto-success', 'dbauto-fail');
        });

        const delay = (ms) => new Promise(r => setTimeout(r, ms));

        // 매핑 테이블 (config에서 가져오거나 폴백)
        const provCdMap = CFG.PROV_CD_MAP || { '제공': 'A', '부가업무': 'B', '거부': 'C' };
        const meansMap = CFG.MEANS_MAP || { '전화': 'A', '내방': 'B', '방문': 'C' };
        const locMap = CFG.LOCATION_MAP || { '기관내': 'A', '아동가정': 'B', '유관기관': 'C', '기타': 'X' };
        const svcMap = CFG.SERVICE_MAP || {};

        // 1. 제공구분 (Radio)
        smartFillRadio('provCd', provCdMap[data.provCd_val] || data.provCd_val || '');

        // 2. 서비스제공방법 (Select)
        smartFill(F.MEANS || 'provMeansCd', meansMap[data.provMeansCd_val] || data.provMeansCd_val || '');

        // 3. 서비스제공유형
        if (data.provTyCd_val) {
            smartFill(F.TYPE || 'provTyCd', data.provTyCd_val);
        } else {
            markFail(F.TYPE || 'provTyCd');
        }

        // 4. 제공서비스 (Select)
        smartFill(F.SERVICE_DETAIL || 'svcClassDetailCd', svcMap[data.svcClassDetailCd_val] || data.svcClassDetailCd_val || '');

        // 5. 대상자 — 개인정보 보호 차원에서 자동 입력 제외
        markFail(F.RECIPIENT_TYPE || 'svcExecRecipientTyCd');
        markFail(F.RECIPIENT_ID || 'svcExecRecipientId');

        // 6. 제공장소
        smartFill(F.LOCATION || 'svcProvLocCd', locMap[data.loc_val] || data.loc_val || '');
        if (data.locEtc_val_raw) {
            smartFill(F.LOCATION_ETC || 'svcProvLocEtc', data.locEtc_val_raw);
        }

        // 6-2. 서비스 제공 횟수
        if (data.cnt_val !== undefined && data.cnt_val !== '') {
            smartFill(F.PROV_COUNT || 'svcProvCnt', data.cnt_val);
        }

        // 7. 서비스제공일시
        if (data.dateTime_val) {
            const parts = data.dateTime_val.toString().trim().split(' ');
            if (parts.length >= 2) {
                const datePart = parts[0];
                const isDateValid = /^\d{4}-\d{2}-\d{2}$/.test(datePart);

                if (isDateValid) {
                    smartFill(F.START_DATE || 'svcProvStartDate', datePart);
                    smartFill(F.END_DATE || 'svcProvEndDate', datePart);
                } else {
                    smartFill(F.START_DATE || 'svcProvStartDate', datePart, true);
                    smartFill(F.END_DATE || 'svcProvEndDate', datePart, true);
                }

                const timePart = parts[1];
                if (timePart.includes('~')) {
                    const [start, end] = timePart.split('~');
                    const [sh, sm] = start.split(':');
                    const [eh, em] = end.split(':');
                    smartFill(F.START_HH || 'svcProvStartHH', sh);
                    smartFill(F.START_MI || 'svcProvStartMI', sm);
                    smartFill(F.END_HH || 'svcProvEndHH', eh);
                    smartFill(F.END_MI || 'svcProvEndMI', em);
                }
            } else {
                markFail(F.START_DATE || 'svcProvStartDate');
                markFail(F.END_DATE || 'svcProvEndDate');
            }
        } else {
            markFail(F.START_DATE || 'svcProvStartDate');
            markFail(F.END_DATE || 'svcProvEndDate');
        }

        // 8. 이동소요시간
        if (data.mvmnReqreHr_val !== undefined && data.mvmnReqreHr_val !== '') {
            smartFill(F.MOVE_TIME || 'mvmnReqreHr', data.mvmnReqreHr_val);
        } else {
            markFail(F.MOVE_TIME || 'mvmnReqreHr');
        }

        // 9. 서비스내용 & 소견
        smartFill(F.DESC || 'svcProvDesc', data.desc_val);
        smartFill(F.OPINION || 'consOpn', data.opn_val);

        // 10. 서비스 제공자 — 개인정보 보호 차원에서 자동 입력 제외
        markFail(F.PIC || 'picId');

    } catch (e) {
        console.error('dbauto error:', e);
    }
}

function smartFill(id, value, forceFail = false) {
    const el = document.getElementById(id);
    if (!el) return;

    if (!forceFail && value !== undefined && value !== null && value !== '') {
        el.value = value;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.classList.add('dbauto-success');
        setTimeout(() => el.classList.remove('dbauto-success'), 1500);
    } else {
        if (value) el.value = value;
        el.classList.add('dbauto-fail');
    }
}

function smartFillRadio(name, value) {
    const radio = document.querySelector(`input[name="${name}"][value="${value}"]`);
    if (radio) {
        radio.checked = true;
    } else {
        const firstRadio = document.querySelector(`input[name="${name}"]`);
        if (firstRadio) firstRadio.parentElement.classList.add('dbauto-fail');
    }
}

function markFail(id) {
    const el = document.getElementById(id);
    if (el) el.classList.add('dbauto-fail');
}
