// =============================================
// ui/excel-handler.js — 엑셀 파싱 & 레코드 표시
// 책임: 파일 업로드, SheetJS 파싱, 레코드 UI 생성
// =============================================
window.DBAuto = window.DBAuto || {};

window.DBAuto.ExcelHandler = {

    init() {
        const dropZone = document.getElementById('drop-zone');
        const fileInput = document.getElementById('file-input');

        dropZone.addEventListener('click', () => fileInput.click());
        fileInput.addEventListener('change', (e) => this._handleFile(e));
        dropZone.addEventListener('dragover', (e) => { e.preventDefault(); e.target.style.background = '#e8ffd9'; });
        dropZone.addEventListener('dragleave', (e) => { e.preventDefault(); e.target.style.background = '#fff'; });
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            e.target.style.background = '#fff';
            if (e.dataTransfer.files.length > 0) this._handleFile({ target: { files: e.dataTransfer.files } });
        });
    },

    _handleFile(e) {
        const file = e.target.files[0];
        if (!file) return;

        document.getElementById('status').innerText = '';
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const data = new Uint8Array(e.target.result);
                const workbook = XLSX.read(data, { type: 'array' });
                const sheet = workbook.Sheets[workbook.SheetNames[0]];
                const rows = XLSX.utils.sheet_to_json(sheet, { header: 1 });

                const results = this._parseVerticalData(rows);
                if (results.length > 0) {
                    window.DBAuto.HistoryManager.save(file.name, results);
                    this.displayRecords(results);
                    document.getElementById('current-section').classList.remove('hidden');
                }
            } catch (err) {
                document.getElementById('status').innerText = '분석 오류: ' + err.message;
            }
        };
        reader.readAsArrayBuffer(file);
    },

    _parseVerticalData(rows) {
        const results = [];
        for (let col = 1; col <= 7; col++) {
            if (!rows[4] || !rows[4][col]) continue;
            results.push({
                id: col,
                provCd_val: rows[2] ? rows[2][col] : '',
                provMeansCd_val: rows[3] ? rows[3][col] : '',
                svcClassDetailCd_val: rows[4] ? rows[4][col] : '',
                recipient_val: rows[5] ? rows[5][col] : '',
                dateTime_val: rows[6] ? rows[6][col] : '',
                loc_val: rows[7] ? rows[7][col] : '',
                pic_val: rows[8] ? rows[8][col] : '',
                cnt_val: rows[9] ? rows[9][col] : '',
                desc_val: rows[10] ? rows[10][col] : '',
                opn_val: rows[11] ? rows[11][col] : ''
            });
        }
        return results;
    },

    displayRecords(records) {
        window.DBAuto.State.currentParsedData = records;
        const list = document.getElementById('current-records');
        list.innerHTML = '';
        records.forEach(r => list.appendChild(this._createRecordElement(r)));
    },

    _createRecordElement(r, timestamp) {
        const State = window.DBAuto.State;
        const cfg = window.DBAuto.Config;
        const orderIndex = State.selectedRecords.findIndex(sr => sr.id === r.id);
        const isSelected = orderIndex > -1;
        const color = isSelected ? cfg.MATCH_COLORS[orderIndex % cfg.MATCH_COLORS.length] : '#ccc';

        const row = document.createElement('div');
        row.className = `item-row ${isSelected ? 'selected' : ''}`;

        row.innerHTML = `
            <input type="checkbox" class="checkbox" ${isSelected ? 'checked' : ''}>
            ${isSelected ? `<span class="match-badge" style="background:${color}; color:#fff;">${orderIndex + 1}</span>` : `<span class="window-badge" style="background:#ccc;">데이터</span>`}
            <div class="item-info">
                <div class="item-title">케이스 ${r.id}: ${r.svcClassDetailCd_val || '-'}</div>
                <div class="item-tags">
                    <span class="tag">🕒 ${r.dateTime_val || '일시 미입력'}</span>
                    ${r.recipient_val ? `<span class="tag">👤 ${r.recipient_val}</span>` : ''}
                    ${r.provMeansCd_val ? `<span class="tag">📞 ${r.provMeansCd_val}</span>` : ''}
                    ${r.loc_val ? `<span class="tag">📍 ${r.loc_val}</span>` : ''}
                    ${r.pic_val ? `<span class="tag">👨‍💼 ${r.pic_val}</span>` : ''}
                </div>
                ${timestamp ? `<div class="upload-time">업로드: ${window.DBAuto.Utils.getRelativeTime(timestamp)}</div>` : ''}
            </div>
        `;

        row.onclick = () => {
            const index = State.selectedRecords.findIndex(sr => sr.id === r.id);
            if (index > -1) {
                State.selectedRecords.splice(index, 1);
            } else {
                State.selectedRecords.push(r);
            }
            this.displayRecords(State.currentParsedData);
            window.DBAuto.WindowManager.updateStatus();
        };

        return row;
    },
};
