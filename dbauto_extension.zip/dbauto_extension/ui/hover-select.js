// =============================================
// ui/hover-select.js — 호버 드롭다운 UX 전용 모듈
// 책임: 마우스 오버 시 드롭다운 확장/축소, 닫기 처리
// =============================================
window.DBAuto = window.DBAuto || {};

window.DBAuto.HoverSelect = {
    init() {
        // 마우스 오버 시 드롭다운 자동 전개
        document.addEventListener('mouseover', (e) => {
            if (e.target.matches('select.hover-select')) {
                // 다른 열려있는 호버 셀렉트는 모두 닫기
                document.querySelectorAll('select.hover-select[data-is-hovered="true"]').forEach(select => {
                    if (select !== e.target) this.close(select);
                });

                const select = e.target;
                if (select.options.length <= 1) return;
                if (select.dataset.isHovered === 'true') return;

                select.dataset.isHovered = 'true';
                select.size = Math.min(select.options.length, 8);
                select.style.zIndex = '9999';
                select.style.boxShadow = '0 4px 12px rgba(0,0,0,0.2)';
                select.style.height = 'auto';
            }

            // 날짜 입력 필드 자동 피커 열기
            if (e.target.matches('input[type="date"]')) {
                try { e.target.showPicker(); } catch (err) { }
            }
        });

        // 마우스 아웃 시 닫기
        document.addEventListener('mouseout', (e) => {
            if (e.target.matches('select.hover-select')) {
                if (!e.relatedTarget || !e.target.contains(e.relatedTarget)) {
                    this.close(e.target);
                }
            }
        });

        // 값 변경 시 닫기 + 리스트 빌더 자동 추가
        document.addEventListener('change', (e) => {
            if (e.target.matches('select.hover-select')) {
                this.close(e.target);
                // 리스트 빌더 자동 추가 로직
                if (e.target.classList.contains('builder-select-picId') || e.target.classList.contains('builder-select-svcExecRecipientId')) {
                    const container = e.target.closest('.list-builder-container');
                    const field = container.dataset.field;
                    const tabId = container.dataset.tabid;
                    window.addListItem(field, tabId);
                    setTimeout(() => { e.target.value = ""; }, 50);
                }
            }

            // 대상자 구분 변경 시 이름 동적 렌더링
            if (e.target.classList.contains('manual-input-svcExecRecipientTyCd')) {
                const Actions = window.DBAuto.Actions;
                const tabId = parseInt(e.target.dataset.tabid, 10);
                const tyCdVal = e.target.value;
                const container = e.target.closest('.manual-form-group');
                const targetSelect = container.querySelector('.builder-select-svcExecRecipientId');

                if (targetSelect && tyCdVal) {
                    targetSelect.innerHTML = '<option value="">로딩 중...</option>';
                    chrome.tabs.sendMessage(tabId, { action: Actions.UPDATE_TY_CD, value: tyCdVal, silent: true }, (res) => {
                        if (!chrome.runtime.lastError && res && res.svcExecRecipientId) {
                            targetSelect.innerHTML = '<option value="">선택하세요</option>' +
                                res.svcExecRecipientId.map(o => `<option value="${o.value}">${o.text}</option>`).join('');
                        } else {
                            targetSelect.innerHTML = '<option value="">선택하세요</option>';
                        }
                    });
                }
                window.DBAuto.ManualForm.saveState();
            }
        });

        // 드롭다운 내 옵션 클릭(같은 옵션 재클릭 포함) 시 무조건 닫기
        document.addEventListener('mousedown', (e) => {
            if (e.target.tagName === 'OPTION' && e.target.parentElement.matches('select.hover-select')) {
                setTimeout(() => this.close(e.target.parentElement), 0);
            }
            if (e.target.matches('select.hover-select') && e.target.size > 1) {
                setTimeout(() => this.close(e.target), 0);
            }
        });

        // 날짜 입력 클릭 시 피커 열기 + 빌더 아이템 제거
        document.addEventListener('click', (e) => {
            if (e.target.matches('.builder-remove-btn')) {
                e.target.parentElement.remove();
                window.DBAuto.ManualForm.saveState();
            } else if (e.target.matches('input[type="date"]')) {
                try { e.target.showPicker(); } catch (err) { }
            }
        });
    },

    close(select) {
        if (select.dataset.isHovered !== 'true') return;
        select.size = 1;
        select.style.zIndex = '10';
        select.style.boxShadow = 'none';
        select.style.height = '';
        select.dataset.isHovered = 'false';
        select.blur();
    },
};
