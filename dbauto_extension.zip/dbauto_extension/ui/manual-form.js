// =============================================
// ui/manual-form.js — 수동 기입 폼 렌더링 & 상태 관리
// 책임: 폼 HTML 생성, 상태 저장/복원, 일괄 복사, 리스트 빌더
// =============================================
window.DBAuto = window.DBAuto || {};

window.DBAuto.ManualForm = {
    _isRendering: false,

    init() {
        const container = document.getElementById('manual-form-container');

        // 새로고침 버튼 — 저장 상태 초기화 후 재렌더링
        document.getElementById('refresh-manual-windows').onclick = () => {
            this._isRendering = true;
            chrome.storage.local.set({ manualFormState: {} }, () => {
                this.renderForms();
                setTimeout(() => { this._isRendering = false; }, 500);
            });
        };

        // 폼 입력 시 자동 저장
        container.addEventListener('input', () => this.saveState());
        container.addEventListener('change', () => this.saveState());

        // 이벤트 위임: 개별 전송 / 복사 버튼 (MV3 CSP로 inline onclick 차단 우회)
        container.addEventListener('click', (e) => {
            const sendBtn = e.target.closest('[data-action="send-single"]');
            const copyBtn = e.target.closest('[data-action="copy-all"]');
            if (sendBtn) {
                const tabId = parseInt(sendBtn.dataset.tabid);
                this._handleSingleFill(tabId);
            } else if (copyBtn) {
                const tabId = parseInt(copyBtn.dataset.tabid);
                this._handleCopyAll(tabId);
            }
        });

        // 수동 일괄 기입 전송 버튼
        document.getElementById('manual-fill-btn').onclick = () => this._handleManualFill();

        // textarea 자동 높이 조절
        container.addEventListener('input', (e) => {
            if (e.target.tagName === 'TEXTAREA') {
                e.target.style.height = 'auto';
                e.target.style.height = e.target.scrollHeight + 'px';
            }
        });

        // 🔍 확대 편집 모달
        container.addEventListener('click', (e) => {
            const expandBtn = e.target.closest('.expand-btn');
            if (!expandBtn) return;
            const field = expandBtn.dataset.field;
            const tabId = expandBtn.dataset.tabid;
            const textarea = container.querySelector(`.manual-input-${field}[data-tabid="${tabId}"]`);
            if (!textarea) return;
            this._openExpandModal(textarea);
        });
    },

    // ─── 폼 렌더링 ───
    async renderForms() {
        const container = document.getElementById('manual-form-container');
        container.innerHTML = '<div style="text-align:center; padding:15px; color:#666; font-size:11px;">대상 창을 검색 중입니다...</div>';

        const tabs = await window.DBAuto.Messenger.queryTargetTabs();

        if (tabs.length === 0) {
            container.innerHTML = '<div style="text-align:center; padding:15px; color:#999; font-size:11px;">감지된 시스템 창이 없습니다.<br>아동학대정보시스템 창을 열어주세요.</div>';
            return;
        }

        container.innerHTML = '';
        const Actions = window.DBAuto.Actions;

        tabs.forEach((tab, index) => {
            chrome.tabs.sendMessage(tab.id, { action: Actions.GET_FORM_OPTIONS }, (options) => {
                if (chrome.runtime.lastError || !options) {
                    container.insertAdjacentHTML('beforeend', this._createFormHtml(tab, {}, index));
                } else {
                    container.insertAdjacentHTML('beforeend', this._createFormHtml(tab, options, index));
                }
                this._restoreState(tab.id, document.getElementById(`manual-form-${tab.id}`));
            });
        });
    },

    // ─── 상태 저장 ───
    saveState() {
        if (this._isRendering) return;
        chrome.storage.local.get(['manualFormState'], (res) => {
            const state = res.manualFormState || {};
            document.querySelectorAll('.manual-form-group').forEach(group => {
                const tabId = group.id.replace('manual-form-', '');
                if (!state[tabId]) state[tabId] = {};

                group.querySelectorAll('.form-input').forEach(el => {
                    const inputClass = Array.from(el.classList).find(c => c.startsWith('manual-input-'));
                    if (inputClass) {
                        const key = inputClass.replace('manual-input-', '');
                        state[tabId][key] = el.value;
                    }
                });

                group.querySelectorAll('.list-builder-container').forEach(container => {
                    const field = container.dataset.field;
                    const items = Array.from(container.querySelectorAll('.builder-item')).map(it => ({
                        value: it.dataset.value,
                        text: it.dataset.text,
                        tyCd: it.dataset.tycd || ''
                    }));
                    state[tabId][field] = items;
                });
            });
            try {
                chrome.storage.local.set({ manualFormState: state });
            } catch (e) {
                console.error("Export failed:", e);
            }
        });
    },

    // ─── 상태 복원 ───
    _restoreState(tabId, groupEl) {
        if (!groupEl) return;
        chrome.storage.local.get(['manualFormState'], (res) => {
            const state = res.manualFormState;
            if (!state || !state[tabId]) return;

            const tabState = state[tabId];
            groupEl.querySelectorAll('.form-input').forEach(el => {
                const inputClass = Array.from(el.classList).find(c => c.startsWith('manual-input-'));
                if (inputClass) {
                    const key = inputClass.replace('manual-input-', '');
                    if (tabState[key] !== undefined) el.value = tabState[key];
                }
            });

            groupEl.querySelectorAll('.list-builder-container').forEach(container => {
                const field = container.dataset.field;
                const items = tabState[field];
                if (Array.isArray(items)) {
                    const list = container.querySelector(`.builder-list-${field}`);
                    list.innerHTML = '';
                    items.forEach(it => this.renderBuilderItem(list, it.value, it.text, it.tyCd));
                }
            });
        });
    },

    // ─── 폼 HTML 생성 ───
    _createFormHtml(tab, options, index) {
        const buildSelect = (id, opts = [], extraStyle = '') => {
            const safeOpts = (opts || []).filter(o => o.value && !o.text.includes('선택'));
            return `<div class="hover-select-wrapper" style="position: relative; ${extraStyle}">
                <select autocomplete="off" class="form-input manual-input-${id} hover-select" data-tabid="${tab.id}" style="width: 100%; position: absolute; top:0; left:0; box-sizing: border-box; z-index:10; min-height:22px; appearance:auto; cursor:pointer; background:#fff;">
                    ${safeOpts.map(o => `<option value="${o.value}">${o.text}</option>`).join('')}
                </select>
                <div style="visibility: hidden; min-height:22px; width: 100%; pointer-events:none; padding:3px 5px; font-size:10px;">&nbsp;</div>
            </div>`;
        };

        const buildListBuilder = (id, opts = []) => {
            const safeOpts = (opts || []).filter(o => o.value && !o.text.includes('선택'));
            return `
            <div class="list-builder-container" data-field="${id}" data-tabid="${tab.id}">
                <div style="display:flex; gap:3px;">
                    <div class="hover-select-wrapper" style="position: relative; flex:1;">
                        <select autocomplete="off" class="form-input builder-select-${id} hover-select" style="width: 100%; position: absolute; top:0; left:0; box-sizing: border-box; z-index:10; min-height:22px; appearance:auto; cursor:pointer; background:#fff;">
                            ${safeOpts.map(o => `<option value="${o.value}">${o.text}</option>`).join('')}
                        </select>
                        <div style="visibility: hidden; min-height:22px; width: 100%; pointer-events:none; padding:3px 5px; font-size:10px;">&nbsp;</div>
                    </div>
                </div>
                <div class="builder-list-${id}" style="margin-top:3px; display:flex; flex-wrap:wrap; gap:3px;"></div>
            </div>`;
        };

        const buildInput = (id, placeholder, extraStyle = '', attr = '', type = 'text') => {
            return `<input type="${type}" class="form-input manual-input-${id}" data-tabid="${tab.id}" placeholder="${placeholder}" style="${extraStyle}" ${attr}>`;
        };

        // 피해아동 이름 마스킹 처리
        let childText = '';
        if (options.victimNames && options.victimNames.length > 0) {
            const children = options.victimNames
                .map(t => t.replace(/\[피해아동\]\s*/g, '').trim())
                .filter(n => n.length > 0);

            const maskName = (name) => {
                if (name.length <= 1) return name;
                if (name.length === 2) return name[0] + 'O';
                return name[0] + 'O'.repeat(name.length - 2) + name[name.length - 1];
            };

            const uniqueChildren = [...new Set(children.map(maskName))];
            if (uniqueChildren.length > 0) {
                childText = ` (피해아동: ${uniqueChildren.join(', ')})`;
            }
        }

        return `
        <div class="manual-form-group" id="manual-form-${tab.id}">
        <div class="manual-form-title">
            <span class="window-badge">창 ${index + 1}</span>
            ${tab.title || '제목 없음'}${childText}
            <button class="copy-all-btn" data-action="copy-all" data-tabid="${tab.id}">복사 ⬇</button>
        </div>
        
        <div style="font-size: 11px; color: #6b7684; background: #f7f8f9; padding: 10px; border-radius: 8px; border: 1px solid #e5e8eb; margin-bottom: 10px; word-break: keep-all; line-height: 1.5; text-align: left;">
            <span style="font-weight: 600; color: #333d4b;">🔒 대상자·담당자는 시스템에서 직접 선택해 주세요.</span>
            <div style="color: #8b95a1; font-size: 10px; margin-top: 3px;">※ 모든 데이터는 서버에 저장되지 않습니다.</div>
        </div>
        
        <div class="form-row"><div class="form-label">제공구분</div>
            ${buildSelect('provCd', [{ value: '제공', text: '제공' }, { value: '부가업무', text: '부가업무' }, { value: '거부', text: '거부' }], 'flex:1')}
        </div>
        
        <div class="form-row"><div class="form-label">제공방법</div>${buildSelect('provMeansCd', options.provMeansCd, 'flex:1')}</div>
        
        <div class="form-row"><div class="form-label">서비스유형</div>${buildSelect('provTyCd', options.provTyCd, 'flex:1')}</div>
        
        <div class="form-row"><div class="form-label">제공서비스</div>${buildSelect('svcClassDetailCd', options.svcClassDetailCd, 'flex:1')}</div>
        
        <div class="form-row"><div class="form-label">제공장소</div>
            <div style="display:flex; gap:5px; flex:1;">
                ${buildSelect('svcProvLocCd', options.svcProvLocCd, 'flex:1; max-width:120px;')}
                ${buildInput('svcProvLocEtc', '기타 장소 입력', 'flex:1')}
            </div>
        </div>
        <div class="form-row"><div class="form-label">제공일시</div>
            <div style="display:flex; flex-wrap:nowrap; gap:2px; flex:1; align-items:center; font-size:11px; white-space:nowrap; overflow:hidden;">
                ${buildInput('startDate', '', 'width:105px; padding:0 2px;', '', 'date')}
                ${buildInput('startHH', 'HH', 'width:24px; text-align:center; padding:0;', 'maxlength="2"')}시
                ${buildInput('startMI', 'MM', 'width:24px; text-align:center; padding:0;', 'maxlength="2"')}분~
                ${buildInput('endDate', '', 'width:105px; padding:0 2px;', '', 'date')}
                ${buildInput('endHH', 'HH', 'width:24px; text-align:center; padding:0;', 'maxlength="2"')}시
                ${buildInput('endMI', 'MM', 'width:24px; text-align:center; padding:0;', 'maxlength="2"')}분
            </div>
        </div>
        
        <div class="form-row"><div class="form-label"></div>
            <div style="display:flex; gap:5px; flex:1; align-items:center; font-size:10px;">
                제공횟수 ${buildInput('cnt_val', '1', 'width:30px; text-align:center')}회, 
                이동소요 ${buildInput('mvmnReqreHr_val', '0', 'width:40px; text-align:center')}분
            </div>
        </div>

        <div class="form-row" style="align-items:flex-start;"><div class="form-label" style="padding-top:5px;">서비스내용</div>
            <div style="flex:1; position:relative;">
                <textarea class="form-input manual-input-desc_val" data-tabid="${tab.id}" placeholder="서비스 내용 입력" rows="2" style="width:100%; resize:none; overflow:hidden; min-height:36px;"></textarea>
                <span class="expand-btn" data-field="desc_val" data-tabid="${tab.id}" title="확대 편집">🔍</span>
            </div>
        </div>
        <div class="form-row" style="align-items:flex-start;"><div class="form-label" style="padding-top:5px;">상담소견</div>
            <div style="flex:1; position:relative;">
                <textarea class="form-input manual-input-opn_val" data-tabid="${tab.id}" placeholder="상담 소견 입력" rows="2" style="width:100%; resize:none; overflow:hidden; min-height:36px;"></textarea>
                <span class="expand-btn" data-field="opn_val" data-tabid="${tab.id}" title="확대 편집">🔍</span>
            </div>
        </div>
        <div style="display:flex; justify-content:flex-end; margin-top:8px;">
            <button class="btn-send-single" data-action="send-single" data-tabid="${tab.id}">이 창에 전송</button>
        </div>
    </div>
    `;
    },

    // ─── 확대 편집 모달 ───
    _openExpandModal(sourceTextarea) {
        const overlay = document.createElement('div');
        overlay.className = 'expand-modal-overlay';
        overlay.innerHTML = `
            <div class="expand-modal">
                <div class="expand-modal-header">
                    <span style="font-weight:600; font-size:14px;">📝 텍스트 편집</span>
                    <button class="expand-modal-close">✕</button>
                </div>
                <textarea class="expand-modal-textarea">${sourceTextarea.value}</textarea>
                <div class="expand-modal-footer">
                    <span class="expand-modal-count">${sourceTextarea.value.length}자</span>
                    <button class="expand-modal-save btn btn-primary">저장</button>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);

        const modalTextarea = overlay.querySelector('.expand-modal-textarea');
        const countEl = overlay.querySelector('.expand-modal-count');
        modalTextarea.focus();
        modalTextarea.addEventListener('input', () => {
            countEl.textContent = modalTextarea.value.length + '자';
        });

        const close = () => { overlay.remove(); };
        overlay.querySelector('.expand-modal-close').onclick = close;
        overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
        overlay.querySelector('.expand-modal-save').onclick = () => {
            sourceTextarea.value = modalTextarea.value;
            sourceTextarea.style.height = 'auto';
            sourceTextarea.style.height = sourceTextarea.scrollHeight + 'px';
            sourceTextarea.dispatchEvent(new Event('input', { bubbles: true }));
            this.saveState();
            close();
        };
    },

    // ─── 리스트 빌더 항목 렌더링 ───
    renderBuilderItem(parent, value, text, tyCd = '') {
        const item = document.createElement('span');
        item.className = 'builder-item';
        item.dataset.value = value;
        item.dataset.text = text;
        if (tyCd) item.dataset.tycd = tyCd;
        item.style.cssText = 'background:#f2f4f6; border:1px solid #d1d6db; border-radius:12px; padding:2px 8px; font-size:10px; display:inline-flex; align-items:center; gap:4px; color:#333d4b;';
        item.innerHTML = `${text} <span class="builder-remove-btn" style="cursor:pointer; font-weight:bold; color:#8b95a1;">×</span>`;
        parent.appendChild(item);
    },

    // ─── 폼 그룹에서 레코드 데이터 추출 (공통) ───
    _buildRecordFromGroup(group, label) {
        const getVal = (id) => {
            const el = group.querySelector(`.manual-input-${id}`);
            return el ? el.value : '';
        };

        const getListBuilderVal = (id) => {
            const items = group.querySelectorAll(`.list-builder-container[data-field="${id}"] .builder-item`);
            return Array.from(items).map(it => it.dataset.text).join(',');
        };

        const getListBuilderFullVal = (id) => {
            const items = group.querySelectorAll(`.list-builder-container[data-field="${id}"] .builder-item`);
            return Array.from(items).map(it => ({
                value: it.dataset.value,
                text: it.dataset.text.trim(),
                tyCd: (it.dataset.tycd || '').trim()
            }));
        };

        const sd = getVal('startDate'), sh = getVal('startHH'), sm = getVal('startMI');
        const ed = getVal('endDate'), eh = getVal('endHH'), em = getVal('endMI');
        let dateTime_val = '';
        if (sd && sh && sm && ed && eh && em) {
            dateTime_val = `${sd} ${sh}:${sm}~${eh}:${em}`;
        }

        return {
            id: label,
            provCd_val: getVal('provCd'),
            provTyCd_val: getVal('provTyCd'),
            svcClassDetailCd_val: getVal('svcClassDetailCd'),
            recipient_val: getListBuilderVal('svcExecRecipientId'),
            recipient_fullVal: getListBuilderFullVal('svcExecRecipientId'),
            recipientTy_val_raw: getVal('svcExecRecipientTyCd'),
            provMeansCd_val: getVal('provMeansCd'),
            loc_val: getVal('svcProvLocCd'),
            locEtc_val_raw: getVal('svcProvLocEtc'),
            pic_val: getListBuilderVal('picId'),
            pic_fullVal: getListBuilderFullVal('picId'),
            dateTime_val: dateTime_val,
            mvmnReqreHr_val: getVal('mvmnReqreHr_val'),
            desc_val: getVal('desc_val'),
            opn_val: getVal('opn_val'),
            cnt_val: getVal('cnt_val') || 1
        };
    },

    // ─── 다른 등 복사 ───
    _handleCopyAll(sourceTabId) {
        const fields = window.DBAuto.Config.MANUAL_FORM_FIELDS;

        fields.forEach(field => {
            const sourceEl = document.querySelector(`.manual-input-${field}[data-tabid="${sourceTabId}"]`);
            if (!sourceEl) return;
            const val = sourceEl.value;
            document.querySelectorAll(`.manual-input-${field}`).forEach(targetEl => {
                if (targetEl.dataset.tabid != sourceTabId) targetEl.value = val;
            });
        });

        document.querySelectorAll('.list-builder-container').forEach(targetContainer => {
            if (targetContainer.dataset.tabid != sourceTabId) {
                const field = targetContainer.dataset.field;
                const sourceItems = Array.from(document.querySelectorAll(
                    `.list-builder-container[data-tabid="${sourceTabId}"][data-field="${field}"] .builder-item`
                ));
                const targetList = targetContainer.querySelector(`.builder-list-${field}`);
                targetList.innerHTML = '';
                sourceItems.forEach(item => {
                    this.renderBuilderItem(targetList, item.dataset.value, item.dataset.text, item.dataset.tycd);
                });
            }
        });

        this.saveState();
    },

    // ─── 개별 창 전송 ───
    _handleSingleFill(tabId) {
        const Actions = window.DBAuto.Actions;
        const group = document.getElementById(`manual-form-${tabId}`);
        if (!group) return alert('해당 창의 폼을 찾을 수 없습니다.');

        const record = this._buildRecordFromGroup(group, `수동-개별`);

        console.log(`[dbauto] Sending data to tab ${tabId}:`, record);
        chrome.tabs.sendMessage(tabId, { action: Actions.START_AUTO_FILL, data: record }, (res) => {
            if (chrome.runtime.lastError) console.error(`기입 실패 (탭 ${tabId}):`, chrome.runtime.lastError);
        });

        alert('입력 요청이 해당 창에 발송되었습니다. 빨간색 필드가 없는지 확인하세요.');
    },

    // ─── 수동 일괄 기입 전송 ───
    _handleManualFill() {
        const Actions = window.DBAuto.Actions;
        const formGroups = document.querySelectorAll('.manual-form-group');
        if (formGroups.length === 0) return alert('기입할 창이 없습니다.');

        const confirmMsg = `현재 작성된 내용으로 ${formGroups.length}개의 창에 기입을 시작하시겠습니까?`;
        if (!confirm(confirmMsg)) return;

        formGroups.forEach((group, i) => {
            const tabId = parseInt(group.id.replace('manual-form-', ''));
            const record = this._buildRecordFromGroup(group, `수동-${i + 1}`);

            console.log(`[dbauto] Sending data to tab ${tabId}:`, record);
            chrome.tabs.sendMessage(tabId, { action: Actions.START_AUTO_FILL, data: record }, (res) => {
                if (chrome.runtime.lastError) console.error(`기입 실패 (탭 ${tabId}):`, chrome.runtime.lastError);
            });
        });

        alert('수동 일괄 입력 요청이 각 창에 발송되었습니다. 창마다 빨간색 필드가 없는지 확인하세요.');
    },
};



window.addListItem = function (field, tabId) {
    const container = document.querySelector(`.list-builder-container[data-field="${field}"][data-tabid="${tabId}"]`);
    const select = container.querySelector(`.builder-select-${field}`);
    const list = container.querySelector(`.builder-list-${field}`);

    let tyCd = '';
    if (field === 'svcExecRecipientId') {
        const group = document.getElementById(`manual-form-${tabId}`);
        const tySelect = group.querySelector('.manual-input-svcExecRecipientTyCd');
        if (tySelect) tyCd = tySelect.value;
    }

    if (!select.value) return;

    if (Array.from(list.querySelectorAll('.builder-item')).some(el => el.dataset.value === select.value)) {
        alert('이미 추가된 항목입니다.');
        return;
    }

    window.DBAuto.ManualForm.renderBuilderItem(list, select.value, select.options[select.selectedIndex].text, tyCd);
    window.DBAuto.ManualForm.saveState();
};
