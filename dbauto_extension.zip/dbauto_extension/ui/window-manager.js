// =============================================
// ui/window-manager.js — 창 스캔, 선택, 일괄 기입 실행
// 책임: 타겟 시스템 창 탐색, 목록 렌더링, 일괄 전송
// =============================================
window.DBAuto = window.DBAuto || {};

window.DBAuto.WindowManager = {

    // 이름 마스킹: 강윤수→강O수, 유나→유O, 제갈도민→제OO민
    _maskName(name) {
        if (!name || name.length <= 1) return name;
        if (name.length === 2) return name[0] + 'O';
        return name[0] + 'O'.repeat(name.length - 2) + name[name.length - 1];
    },

    init() {
        document.getElementById('refresh-windows').onclick = () => this.scanTabs();
        document.getElementById('batch-fill-btn').onclick = () => this._handleBatchFill();
    },

    async scanTabs() {
        const State = window.DBAuto.State;
        const Actions = window.DBAuto.Actions;
        State.targetTabs = await window.DBAuto.Messenger.queryTargetTabs();

        // 이전에 선택했던 탭이 여전히 존재하는지 필터링
        State.selectedTabs = State.selectedTabs.filter(
            st => State.targetTabs.some(t => t.id === st.id)
        );

        // 먼저 목록을 즉시 렌더링
        this._renderList();

        // 피해아동 이름은 비동기로 조회 후 DOM 업데이트
        State.tabVictimNames = State.tabVictimNames || {};
        State.targetTabs.forEach(tab => {
            try {
                chrome.tabs.sendMessage(tab.id, { action: Actions.GET_FORM_OPTIONS }, (options) => {
                    if (chrome.runtime.lastError) return;
                    if (options && options.victimNames && options.victimNames.length > 0) {
                        const names = options.victimNames
                            .map(n => n.replace(/\[피해아동\]\s*/g, '').replace('피해아동 ', '').trim())
                            .filter(n => n.length > 0)
                            .map(n => this._maskName(n))
                            .join(', ');
                        State.tabVictimNames[tab.id] = names;
                        // DOM에서 해당 탭의 제목을 직접 업데이트
                        const rows = document.querySelectorAll('#window-list .item-title');
                        rows.forEach(el => {
                            if (el.textContent.includes(tab.title) && !el.textContent.includes('피해아동')) {
                                el.textContent += ` (피해아동: ${names})`;
                            }
                        });
                    }
                });
            } catch (e) { /* 무시 */ }
        });
    },

    updateStatus() {
        const State = window.DBAuto.State;
        const status = document.getElementById('status');
        if (State.selectedRecords.length > 0 || State.selectedTabs.length > 0) {
            status.innerText = `케이스 ${State.selectedRecords.length}개, 창 ${State.selectedTabs.length}개 선택됨`;
        } else {
            status.innerText = '파일을 대기 중입니다.';
        }
    },

    _renderList() {
        const State = window.DBAuto.State;
        const Actions = window.DBAuto.Actions;
        const cfg = window.DBAuto.Config;
        const list = document.getElementById('window-list');
        list.innerHTML = '';

        if (State.targetTabs.length === 0) {
            list.innerHTML = '<div style="text-align:center; padding:12px; color:#8b95a1; font-size:12px;">감지된 시스템 창이 없습니다.</div>';
            return;
        }

        State.targetTabs.forEach((tab) => {
            const orderIndex = State.selectedTabs.findIndex(st => st.id === tab.id);
            const isSelected = orderIndex > -1;
            const color = isSelected ? cfg.MATCH_COLORS[orderIndex % cfg.MATCH_COLORS.length] : '#ccc';

            const victimNames = (State.tabVictimNames || {})[tab.id];
            const childText = victimNames ? ` (피해아동: ${victimNames})` : '';

            const row = document.createElement('div');
            row.className = `item-row ${isSelected ? 'selected' : ''}`;
            row.innerHTML = `
                <input type="checkbox" class="checkbox" ${isSelected ? 'checked' : ''}>
                ${isSelected ? `<span class="match-badge" style="background:${color}; color:#fff;">${orderIndex + 1}</span>` : `<span class="window-badge">창</span>`}
                <div class="item-info">
                    <div class="item-title">${tab.title || '제목 없음'}${childText}</div>
                    <div style="font-size: 10px; color: #999;">${tab.url.substring(0, 40)}...</div>
                </div>
            `;

            row.onmouseenter = () => chrome.tabs.sendMessage(tab.id, { action: Actions.HIGHLIGHT_TAB, active: true });
            row.onmouseleave = () => chrome.tabs.sendMessage(tab.id, { action: Actions.HIGHLIGHT_TAB, active: false });

            row.onclick = () => {
                const index = State.selectedTabs.findIndex(st => st.id === tab.id);
                if (index > -1) {
                    State.selectedTabs.splice(index, 1);
                } else {
                    State.selectedTabs.push(tab);
                }
                this._renderList();
                this.updateStatus();
            };

            list.appendChild(row);
        });
    },

    _handleBatchFill() {
        const State = window.DBAuto.State;
        const Actions = window.DBAuto.Actions;

        if (State.selectedRecords.length === 0) return alert('기입할 케이스를 먼저 선택해주세요.');
        if (State.selectedTabs.length === 0) return alert('데이터를 넣을 대상 창을 아래 목록에서 클릭해 주세요.');

        const confirmMsg = `${State.selectedRecords.length}개의 데이터를 선택한 ${State.selectedTabs.length}개의 창에 입력하시겠습니까?`;
        if (!confirm(confirmMsg)) return;

        State.selectedRecords.forEach((record, i) => {
            const targetTab = State.selectedTabs[i % State.selectedTabs.length];
            chrome.tabs.sendMessage(targetTab.id, { action: Actions.START_AUTO_FILL, data: record }, (res) => {
                if (chrome.runtime.lastError) console.error(`기입 실패:`, chrome.runtime.lastError);
            });
        });

        alert('자동 입력이 시작되었습니다. 각 창의 미흡한 항목(빨간색)을 확인해 주세요.');
    },
};
